# ProjetXML
Projet XML M1 Informatique 2016

Générer les fichiers xHTML avec la commande :
xsltproc ue.xsl ue.xml

Les répertoires intervenants et unites vont être créés, en plus du documents index.html

Ouvrir le document index.html pour avoir accès à la table des intervenants et des unités.


Fait en binôme par MAGRON Benjamin et LEOTIER Nicolas
